plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "cu.tools"
    compileSdk = 35
    defaultConfig {
        applicationId = "cu.tools"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "0.1"
    }
}
