package cu.tools

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(13, 35, 64)
    private val blue = Color.rgb(22, 76, 130)
    private val teal = Color.rgb(0, 150, 136)
    private val pale = Color.rgb(241, 246, 251)
    private val ink = Color.rgb(29, 43, 58)
    private val muted = Color.rgb(94, 112, 130)
    private lateinit var status: TextView
    private lateinit var simSpinner: Spinner
    private lateinit var customCode: EditText
    private var subscriptions: List<SubscriptionInfo> = emptyList()
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (!hasPhonePermissions()) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 41)
        } else loadSims()
    }

    private fun hasPhonePermissions() =
        checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun rounded(color: Int, radius: Float = 22f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(pale); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
            layoutParams = ViewGroup.LayoutParams(-1, -2)
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = rounded(navy, 28f)
        }
        hero.addView(label("CuTools", 30f, Color.WHITE, true))
        hero.addView(label("Tu móvil cubano, más fácil 🇨🇺", 16f, Color.rgb(194, 222, 242)).apply { setPadding(0, dp(5), 0, 0) })
        hero.addView(label("Accesos rápidos a servicios de ETECSA / Cubacel", 13f, Color.rgb(220, 232, 242)).apply { setPadding(0, dp(12), 0, 0) })
        root.addView(hero, margin(bottom = 16))

        val simCard = card()
        simCard.addView(label("TU LÍNEA", 12f, muted, true))
        simSpinner = Spinner(this)
        simCard.addView(simSpinner, margin(top = 5, bottom = 4))
        simCard.addView(label("En teléfonos con doble SIM, selecciona la línea Cubacel de ETECSA.", 12f, muted))
        root.addView(simCard, margin(bottom = 16))

        root.addView(label("Consultas rápidas", 21f, ink, true), margin(bottom = 9))
        root.addView(label("Consulta tus recursos sin tener que memorizar los códigos.", 13f, muted), margin(bottom = 12))
        val rows = listOf(
            listOf(Action("Saldo principal", "Ver saldo y vigencia", "*222#"), Action("Datos móviles", "Consultar MB disponibles", "*222*328#")),
            listOf(Action("Bonos", "Bonos y recursos promocionales", "*222*266#"), Action("Minutos", "Consultar minutos de voz", "*222*869#")),
            listOf(Action("SMS", "Consultar mensajes disponibles", "*222*767#"), Action("Plan Amigos", "Consultar estado del plan", "*222*264#"))
        )
        rows.forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { action ->
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), dp(15), dp(14), dp(14))
                    background = rounded(Color.WHITE, 20f)
                    elevation = dp(2).toFloat()
                }
                item.addView(label(action.title, 15f, ink, true))
                item.addView(label(action.subtitle, 12f, muted).apply { setPadding(0, dp(5), 0, dp(12)) })
                val b = Button(this).apply {
                    text = "Consultar"; isAllCaps = false; textSize = 13f
                    setTextColor(Color.WHITE); background = rounded(teal, 14f)
                    setPadding(dp(6), 0, dp(6), 0)
                    setOnClickListener { runUssd(action.code) }
                }
                item.addView(b, LinearLayout.LayoutParams(-1, dp(42)))
                val lp = LinearLayout.LayoutParams(0, -1, 1f)
                if (pair.indexOf(action) == 0) lp.marginEnd = dp(8) else lp.marginStart = dp(8)
                row.addView(item, lp)
            }
            root.addView(row, margin(bottom = 12))
        }

        root.addView(label("Servicios y operaciones", 21f, ink, true), margin(top = 8, bottom = 10))
        val services = card()
        services.addView(serviceButton("Comprar planes o paquetes", "Abre el menú oficial *133#", blue) { runUssd("*133#") })
        services.addView(serviceButton("Transferir saldo", "Abre el menú *234#; confirma los datos con cuidado", blue) { runUssd("*234#") }, margin(top = 8))
        services.addView(serviceButton("Recargar con tarjeta", "Abre el marcador con instrucciones de recarga", blue) { openDialer("*662*") }, margin(top = 8))
        services.addView(serviceButton("Atención ETECSA", "Llamar al 52642266", blue) { openDialer("52642266") }, margin(top = 8))
        services.addView(serviceButton("Llamada con cobro revertido", "Introduce el número después de *99", blue) { showNumberDialog("Cobro revertido", "Número de destino") { openDialer("*99$it") } }, margin(top = 8))
        root.addView(services, margin(bottom = 16))

        val custom = card()
        custom.addView(label("Código USSD personalizado", 17f, ink, true))
        custom.addView(label("Para otros códigos de ETECSA. La aplicación no guarda los códigos que escribas.", 12f, muted).apply { setPadding(0, dp(5), 0, dp(10)) })
        customCode = EditText(this).apply {
            hint = "Ejemplo: *222#"; setSingleLine(true); textSize = 16f
            setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(pale, 14f)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        custom.addView(customCode, margin(bottom = 10))
        custom.addView(serviceButton("Ejecutar código", "La red puede pedir confirmación adicional", teal) {
            val code = customCode.text.toString().trim().replace(" ", "")
            if (!code.startsWith("*") || !code.endsWith("#") || code.length < 3) {
                customCode.error = "Escribe un código que comience con * y termine con #"
            } else {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(customCode.windowToken, 0)
                runUssd(code)
            }
        })
        root.addView(custom, margin(bottom = 16))

        root.addView(label("Respuesta de la red", 20f, ink, true), margin(bottom = 8))
        status = TextView(this).apply {
            text = "¡Hola! Selecciona tu SIM y toca una consulta para empezar."
            textSize = 15f; setTextColor(ink); setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(Color.WHITE, 20f); minHeight = dp(110)
        }
        root.addView(status, margin(bottom = 14))
        root.addView(label("Nota: CuTools no es una aplicación oficial de ETECSA. Los códigos, precios y servicios pueden cambiar. Las compras y transferencias se completan únicamente en los menús de la operadora.", 11f, muted))
        scroll.addView(root)
        setContentView(scroll)
    }

    private data class Action(val title: String, val subtitle: String, val code: String)

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.WHITE, 22f); elevation = dp(2).toFloat()
    }

    private fun margin(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun serviceButton(title: String, subtitle: String, color: Int, click: () -> Unit): View {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(pale, 16f)
            isClickable = true; isFocusable = true; setOnClickListener { click() }
        }
        wrapper.addView(label(title, 15f, ink, true))
        wrapper.addView(label(subtitle, 12f, muted).apply { setPadding(0, dp(3), 0, 0) })
        return wrapper
    }

    private fun loadSims() {
        try {
            val manager = getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            subscriptions = manager.activeSubscriptionInfoList ?: emptyList()
            val labels = if (subscriptions.isEmpty()) listOf("No se detectaron SIM activas") else subscriptions.mapIndexed { i, s ->
                val carrier = s.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM"
                "SIM ${i + 1} · $carrier · ranura ${s.simSlotIndex + 1}"
            }
            simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
            status.text = if (subscriptions.isEmpty()) "No se detectaron SIM activas. Comprueba que esté insertada y habilitada." else "SIM detectadas: ${subscriptions.size}. Selecciona la línea ETECSA y elige una consulta."
        } catch (_: SecurityException) { status.text = "Falta permiso para detectar las SIM. Revisa los permisos de teléfono." }
        catch (e: Exception) { status.text = "No se pudieron leer las SIM: ${e.message ?: "error desconocido"}" }
    }

    private fun runUssd(code: String) {
        if (busy) return
        if (!hasPhonePermissions()) { requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 41); return }
        if (subscriptions.isEmpty()) loadSims()
        if (subscriptions.isEmpty()) { status.text = "No hay una SIM activa disponible."; return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) { status.text = "Se necesita Android 8 o superior para mostrar respuestas USSD dentro de CuTools."; return }
        val selected = simSpinner.selectedItemPosition.coerceIn(0, subscriptions.lastIndex)
        val sub = subscriptions[selected]
        busy = true
        status.text = "Consultando $code…\nEspera la respuesta de la red."
        try {
            val manager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            manager.createForSubscriptionId(sub.subscriptionId).sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    runOnUiThread { status.text = "Código: $request\n\n$response"; busy = false }
                }
                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    runOnUiThread {
                        status.text = "No se pudo completar $request (código $failureCode).\n\nComprueba la SIM de ETECSA, la señal y si el operador permite esta consulta desde aplicaciones. Puedes probar el código en la aplicación Teléfono."
                        busy = false
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (_: SecurityException) { status.text = "Permiso denegado. Autoriza los permisos de teléfono."; busy = false }
        catch (e: Exception) { status.text = "Error al iniciar la consulta: ${e.message ?: "operación no disponible"}"; busy = false }
    }

    private fun openDialer(number: String) {
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))) }
        catch (_: Exception) { status.text = "No se pudo abrir el marcador del teléfono." }
    }

    private fun showNumberDialog(title: String, hintText: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply { hint = hintText; inputType = android.text.InputType.TYPE_CLASS_PHONE }
        android.app.AlertDialog.Builder(this).setTitle(title).setMessage("Introduce el número. Revisa el destino antes de continuar.")
            .setView(input).setNegativeButton("Cancelar", null).setPositiveButton("Abrir marcador") { _, _ ->
                val number = input.text.toString().trim()
                if (number.isNotEmpty()) onOk(number) else status.text = "No escribiste un número."
            }.show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) loadSims()
            else status.text = "CuTools necesita permisos de teléfono para detectar la SIM y consultar USSD."
        }
    }
}
