package cu.tools

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var simSpinner: Spinner
    private lateinit var queryButton: Button
    private var subscriptions: List<SubscriptionInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 41)
        } else loadSims()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            gravity = Gravity.TOP
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        root.addView(TextView(this).apply { text = "CuTools"; textSize = 30f; setTextColor(0xFF123A5A.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "Servicios móviles · ETECSA / Cubacel"; textSize = 15f; setTextColor(0xFF536575.toInt()); setPadding(0, 4, 0, 24) })
        root.addView(TextView(this).apply { text = "Selecciona la SIM de ETECSA"; textSize = 16f })
        simSpinner = Spinner(this)
        root.addView(simSpinner)
        queryButton = Button(this).apply { text = "Consultar saldo (*222#)"; isAllCaps = false; setOnClickListener { queryBalance() } }
        root.addView(queryButton)
        root.addView(TextView(this).apply { text = "La respuesta aparecerá aquí. La consulta depende del teléfono, la SIM y la red."; textSize = 14f; setTextColor(0xFF536575.toInt()); setPadding(0, 16, 0, 8) })
        status = TextView(this).apply { text = "Listo para configurar."; textSize = 16f; setTextColor(0xFF17212B.toInt()); setPadding(16, 16, 16, 16); setBackgroundColor(0xFFFFFFFF.toInt()); minHeight = 140 }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun loadSims() {
        try {
            val sm = getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            subscriptions = sm.activeSubscriptionInfoList ?: emptyList()
            val labels = if (subscriptions.isEmpty()) listOf("No se detectaron SIM activas") else subscriptions.mapIndexed { i, s ->
                val carrier = s.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM"
                "SIM ${i + 1} · $carrier · ranura ${s.simSlotIndex + 1}"
            }
            simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
            status.text = if (subscriptions.isEmpty()) "No se detectaron SIM activas. Comprueba que la SIM esté insertada y habilitada." else "SIM detectadas: ${subscriptions.size}. Selecciona la línea ETECSA y pulsa Consultar saldo."
        } catch (_: SecurityException) { status.text = "Falta permiso para leer las SIM. Concede los permisos y vuelve a abrir CuTools." }
        catch (e: Exception) { status.text = "No se pudieron leer las SIM: ${e.message ?: "error desconocido"}" }
    }

    private fun queryBalance() {
        if (subscriptions.isEmpty()) { status.text = "No hay una SIM activa disponible. Revisa la configuración del teléfono."; return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) { status.text = "Se necesita Android 8 o superior para mostrar la respuesta USSD dentro de CuTools."; return }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 41); return
        }
        val selected = simSpinner.selectedItemPosition.coerceIn(0, subscriptions.lastIndex)
        val sub = subscriptions[selected]
        status.text = "Consultando *222# en ${simSpinner.selectedItem}…"
        queryButton.isEnabled = false
        try {
            val base = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            base.createForSubscriptionId(sub.subscriptionId).sendUssdRequest("*222#", object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    runOnUiThread { status.text = "Respuesta de la red:\n\n$response"; queryButton.isEnabled = true }
                }
                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    runOnUiThread { status.text = "No se pudo completar la consulta USSD (código $failureCode).\n\nComprueba que elegiste la SIM ETECSA, que tiene señal y que puede realizar consultas USSD. También puedes marcar *222# desde la app Teléfono."; queryButton.isEnabled = true }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (_: SecurityException) { status.text = "Permiso denegado. Autoriza Teléfono y vuelve a intentarlo."; queryButton.isEnabled = true }
        catch (e: Exception) { status.text = "Error al iniciar la consulta: ${e.message ?: "no disponible"}"; queryButton.isEnabled = true }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) loadSims()
            else status.text = "Necesitamos los permisos de Teléfono para detectar la SIM y consultar USSD."
        }
    }
}
