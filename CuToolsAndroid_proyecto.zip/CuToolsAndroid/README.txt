CuTools Android - prototipo nativo inicial

Incluye proyecto Android en Kotlin, selector de SIM activa, consulta USSD *222# y pantalla para mostrar la respuesta o el error. Contiene un flujo de GitHub Actions para compilar un APK de prueba.

IMPORTANTE: Este proyecto fuente no se ha compilado ni probado en un teléfono real. La función USSD depende del fabricante, Android, permisos, SIM y soporte del operador. El APK de depuración no es una versión firmada para lanzamiento. No incluye todavía transferencias, compras ni recargas, y no automatiza transacciones financieras.

Compilar desde el teléfono con GitHub:
1. Extrae este ZIP en el administrador de archivos.
2. En Chrome abre github.com e inicia sesión.
3. Crea un repositorio nuevo llamado CuToolsAndroid.
4. Sube el CONTENIDO de esta carpeta al repositorio; no subas solo el ZIP. En la raíz deben verse settings.gradle.kts y la carpeta app/.
5. Asegúrate de que también se suba .github/workflows/build-apk.yml.
6. Abre Actions y ejecuta Build CuTools APK (Run workflow), o espera a que compile tras subir los archivos.
7. En la ejecución terminada, descarga el artefacto CuTools-debug-apk desde Artifacts. Allí estará app-debug.apk.
8. Instala el APK y concede los permisos solicitados.

Si Actions no aparece, revisa Settings > Actions > General. Este ZIP contiene código fuente, no un APK ya compilado.
