CuTools 1.0 — proyecto Android inicial mejorado

Interfaz moderna con tarjetas y accesos rápidos para servicios Cubacel/ETECSA. Incluye selección de SIM, consultas USSD dentro de la aplicación y accesos al menú de planes, menú de transferencia, marcador para recarga y atención ETECSA.

Consultas integradas:
- Saldo: *222#
- Datos: *222*328#
- Bonos: *222*266#
- Minutos: *222*869#
- SMS: *222*767#
- Plan Amigos: *222*264#
- Menú de planes: *133#
- Menú de transferencia: *234#

Nota importante: CuTools no está afiliada ni respaldada por ETECSA. Los códigos pueden cambiar. Las funciones USSD dependen de Android, del teléfono, la SIM y la red; por eso no se puede garantizar que todos funcionen en todos los dispositivos. La compra de planes, las recargas y las transferencias se confirman en los menús oficiales de la operadora. No se guardan claves ni números de tarjetas.

Compilación: sube el contenido de esta carpeta al repositorio GitHub o usa el flujo de compilación ya configurado. El APK de depuración sirve para pruebas y no es una versión de lanzamiento firmada.
